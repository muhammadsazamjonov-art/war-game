# ✈ Sky Ace 3D — Havo jangi

3D brauzer o'yini: 8 xarita, 124 samolyot, Arena (26 AI), Baza himoyasi, suv osti kemalari, multiplayer xonalar, PWA (telefonga o'rnatish).

Next.js 16 + Three.js + PostgreSQL (Drizzle ORM).

---

## 🚀 Render + GitHub orqali doimiy saytga chiqarish

### 1-qadam — GitHub'ga yuklash

1. <https://github.com/new> da yangi repo yarating (masalan `sky-ace-3d`). README qo'shmang.
2. Loyiha papkasida terminal oching va yozing:

```bash
git init
git add .
git commit -m "Sky Ace 3D"
git branch -M main
git remote add origin https://github.com/SIZNING_LOGIN/sky-ace-3d.git
git push -u origin main
```

> Bu yerdagi "Download" tugmasi orqali loyihani ZIP qilib yuklab olib, ochib, yuqoridagi buyruqlarni bajaring.
> Terminal ishlatmasangiz: GitHub repo sahifasida **"uploading an existing file"** ni bosib, barcha fayllarni (node_modules va .next dan tashqari) sudrab tashlang.

### 2-qadam — Render'da ishga tushirish (Blueprint)

1. <https://dashboard.render.com> ga GitHub akkaunt bilan kiring.
2. **New +** → **Blueprint** ni bosing.
3. `sky-ace-3d` repo'ni tanlang → Render `render.yaml` ni o'qiydi.
4. **Apply** ni bosing. Render avtomatik:
   - PostgreSQL bazasini (`sky-ace-db`) yaratadi,
   - Web xizmatni (`sky-ace-3d`) build qiladi va ishga tushiradi,
   - `DATABASE_URL` ni ulab qo'yadi.
5. 3–6 daqiqadan so'ng sayt manzili chiqadi: `https://sky-ace-3d.onrender.com`

Jadvallar birinchi so'rovda avtomatik yaratiladi — hech qanday migratsiya kerak emas.

### 3-qadam — Yangilash

Kodni o'zgartirib `git push` qilsangiz, Render saytni avtomatik qayta build qiladi.

---

## 💡 "Vaqtinchalik emas" bo'lishi uchun muhim

| Narsa | Free reja | Doimiy ishlashi uchun |
|---|---|---|
| Web xizmat | 15 daqiqa harakatsizlikdan keyin "uxlaydi", birinchi ochilishda ~50 soniya kutadi | `render.yaml` da `plan: starter` |
| PostgreSQL | **30 kundan keyin o'chiriladi** | `plan: basic-256mb` **yoki** bepul Neon bazasi (pastda) |

### Bepul doimiy baza: Neon

1. <https://neon.tech> da bepul loyiha yarating, **Connection string** ni nusxalang (`postgresql://...sslmode=require`).
2. Render → `sky-ace-3d` xizmati → **Environment** → `DATABASE_URL` ni shu qiymatga almashtiring → **Save** (avtomatik qayta deploy).
3. Xohlasangiz `render.yaml` dan `databases:` bo'limini va `fromDatabase` ni olib tashlab, `DATABASE_URL` ni `sync: false` qilib qo'ying.

### O'z domeningiz

Render → xizmat → **Settings → Custom Domains** → domeningizni qo'shing va DNS'da ko'rsatilgan CNAME yozuvini qo'shing. HTTPS avtomatik beriladi (PWA o'rnatish uchun HTTPS shart).

---

## 🖥 Lokal ishga tushirish

```bash
npm install
echo "DATABASE_URL=postgresql://postgres:postgres@127.0.0.1:5432/app_db" > .env
npm run dev
```

## 🎮 Boshqaruv

W gaz • S tormoz • Shift forsaj • ←/→ burilish • ↑/↓ burun • Q/E rul • Space o'q • F raketa • X issiqlik nishonlari • P pauza • R qayta boshlash.
Telefonda — ekrandagi joystik va tugmalar.
