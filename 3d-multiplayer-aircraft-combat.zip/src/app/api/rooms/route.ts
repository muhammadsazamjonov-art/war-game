import { ensureSchema } from "@/db/ensure";
import { db } from "@/db";
import { rooms } from "@/db/schema";
import { desc, sql } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET() {
  await ensureSchema();
  const rows = await db.select().from(rooms).orderBy(desc(rooms.createdAt)).limit(10);
  return Response.json(rows);
}

export async function POST(req: Request) {
  await ensureSchema();
  const b = await req.json();
  // housekeeping: drop stale rooms/players
  await db.execute(sql`DELETE FROM room_players WHERE updated_at < now() - interval '1 hour'`);
  await db.execute(sql`DELETE FROM rooms WHERE created_at < now() - interval '1 day'`);
  const code = Math.random().toString(36).slice(2, 7).toUpperCase();
  await db.insert(rooms).values({ code, map: String(b.map || "0"), host: String(b.name || "Pilot").slice(0, 16) });
  return Response.json({ code });
}
