import { ensureSchema } from "@/db/ensure";
import { db } from "@/db";
import { rooms, roomPlayers } from "@/db/schema";
import { and, eq, gt, ne, sql } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET(_: Request, ctx: { params: Promise<{ code: string }> }) {
  await ensureSchema();
  const { code } = await ctx.params;
  const r = await db.select().from(rooms).where(eq(rooms.code, code.toUpperCase()));
  if (!r.length) return Response.json({ error: "not found" }, { status: 404 });
  return Response.json(r[0]);
}

// sync: upsert my state, return others
export async function POST(req: Request, ctx: { params: Promise<{ code: string }> }) {
  await ensureSchema();
  const { code: c } = await ctx.params;
  const code = c.toUpperCase();
  const b = await req.json();
  const pid = String(b.pid).slice(0, 40);
  const name = String(b.name || "Pilot").slice(0, 16);
  await db
    .insert(roomPlayers)
    .values({ code, pid, name, state: b.state ?? {} })
    .onConflictDoUpdate({
      target: [roomPlayers.code, roomPlayers.pid],
      set: { state: b.state ?? {}, name, updatedAt: sql`now()` },
    });
  const others = await db
    .select({ pid: roomPlayers.pid, name: roomPlayers.name, state: roomPlayers.state })
    .from(roomPlayers)
    .where(and(eq(roomPlayers.code, code), ne(roomPlayers.pid, pid), gt(roomPlayers.updatedAt, sql`now() - interval '5 seconds'`)));
  return Response.json(others);
}
